package restaurentmanagement;

import java.util.Scanner;

public class RestaurentManagement {

    public static void main(String[] args) {

       new LoginGUI().setVisible(true);
        TimeTable manager = new TimeTable("Wei Hong", "Morning", "CB17071", "Manager");
        TimeTable chef = new TimeTable("Abu", "Morning", "CB17999", "Chef");
        TimeTable waiter = new TimeTable("Yoon Hong", "Morning", "CB17080", "Waiter");
        
        Employee em[] = new TimeTable[2];
        em[0]=new TimeTable();
        em[1]=new TimeTable();
        
        Bill[] bill = new Bill[3];
        bill[0] = new Bill();
        bill[1] = new Bill();
        bill[2] = new Bill();
        
        
        int s, i;
        Menu order1 = new Menu("", 50, 1,bill[0]) {};
        int condition = 1;
        while (condition == 1) {

            //public InventoryControl(int ChickenChopQTY, int SteakQTY, int LambQTY, int SaladQTY, int MushroomSoupQTY, int LobsterSoupQTY, int OrangeJuiceQTY, int PremiumCoffeeQTY)
            Stock stock = new Stock(20, 10, 5, 20, 10, 5, 20, 15);
            System.out.println("\n\n Welcome to ABC Restaurant Management System ");
            System.out.println(" 1. Employee's Timetable. ");
            System.out.println(" 2. Menu. ");
            System.out.println(" 3. Stock Checking. ");
            System.out.println(" 0. Exit System. ");
            Scanner scanner = new Scanner(System.in);
            s = scanner.nextInt();

            switch (s) {
                case 1:
                    System.out.println(" Check Schedule of ...");
                    System.out.println(" 1. Manager ");
                    System.out.println(" 2. Cheft ");
                    System.out.println(" 3. Waiter. ");
                    int s1;
                    s1 = scanner.nextInt();
//                    switch (s1) {
//                        case 1:
//                            manager.First();
//                            System.out.println("\n Salary of today is " + EM1.getSalary());
//                            break;
//                        case 2:
//                            chef.First();
//                            System.out.println("\n Salary of today is " + EM2.getSalary());
//                            break;
//                        case 3:
//                            System.out.println("\n Salary of today is " + EM3.getSalary());
//                            waiter.First();
//                            break;
//                        default:
//                            System.out.println("\n Invalid Input");
//                            break;
//                    }
                    break;

                case 2:

                    int s2,
                     s3,
                     s4;
                    System.out.println("\n 1. Dine in?");
                    System.out.println(" 2. Take away?");
                    s2 = scanner.nextInt();

                    if (s2 == 1) {
                        System.out.println("\n Table Number? ");
                        s3 = scanner.nextInt();
                    }

                    System.out.println("\n Menu : ");
                    order1.menu();
                    System.out.println("\n\nWhat set? ");
                    bill[0].setSetmeal(scanner.nextInt());
                    switch (bill[0].getTemp()) {
                        case 1:
                            order1.setmeal = "Set Meal 1";
                            break;
                        case 2:
                            order1.setmeal = "Set Meal 2";
                            break;
                        case 3:
                            order1.setmeal = "Set Meal 3";
                            break;
                        default:
                            break;
                    }

                    System.out.println(" Payment (RM):");
                    bill[0].setPaid(scanner.nextInt());
                    order1.Second();
                    bill[0].ForBill();
                    break;

                case 3:
                    stock.getSetMeal();
                    stock.StockDisplay();
                    break;

                case 0:
                    condition = 0;
                    exit();
                    break;
                default:
                    break;
            }

        }

    }

    private static void exit() {
        System.out.println("\n\n\n\n\n\n\nWelcome Back Next Time");
    }
    //MainGUI maingui = new MainGUI();
    
}
