package restaurentmanagement;

import java.util.Scanner;
import java.sql.*;
import javax.swing.*;
import net.proteanit.sql.DbUtils;

public class Stock {
    
    public int ChickenChopQTY, SteakQTY, LambQTY;
    public int SaladQTY, MushroomSoupQTY, LobsterSoupQTY;
    public int OrangeJuiceQTY, PremiumCoffeeQTY;
    private String setmeal;
     
    public Stock(int ChickenChopQTY, int SteakQTY, int LambQTY, int SaladQTY, int MushroomSoupQTY, int LobsterSoupQTY, int OrangeJuiceQTY, int PremiumCoffeeQTY) {
        this.ChickenChopQTY = ChickenChopQTY;
        this.SteakQTY = SteakQTY;
        this.LambQTY = LambQTY;
        this.SaladQTY = SaladQTY;
        this.MushroomSoupQTY = MushroomSoupQTY;
        this.LobsterSoupQTY = LobsterSoupQTY;
        this.OrangeJuiceQTY = OrangeJuiceQTY;
        this.PremiumCoffeeQTY = PremiumCoffeeQTY;
    }
    

    public Stock(){
    }

    public String getSetMeal() {
        int s;
        System.out.println(" What Set Meal sold?");
        Scanner scanner6 = new Scanner(System.in);
        s = scanner6.nextInt();
        if (s == 1) {
            setmeal = "Set Meal 1";
        } else if (s == 2) {
            setmeal = "Set Meal 2";
        } else if (s == 3) {
            setmeal = "Set Meal 3";
        }

        return setmeal;
    }

    public String getChickenChopQTY() {
        if (setmeal == "Set Meal 1") {
            ChickenChopQTY = ChickenChopQTY - 1;
        }
        return "Chicken Chop" + ChickenChopQTY + " qty";
    }

    public String getSteakQTY() {
        if (setmeal == "Set Meal 2") {
            SteakQTY = SteakQTY - 1;
        }
        return "Steak" + SteakQTY + " qty";
    }

    public String getLambQTY() {
        if (setmeal == "Set Meal 3") {
            LambQTY = LambQTY - 1;
        }
        return "Lamb" + LambQTY + " qty";
    }

    public String getSaladQTY() {
        if (setmeal == "Set Meal 1") {
            SaladQTY = SaladQTY - 1;
        }
        return "Salad" + SaladQTY + " qty";
    }

    public String getMushroomSoupQTY() {
        if (setmeal == "Set Meal 2") {
            MushroomSoupQTY = MushroomSoupQTY - 1;
        }
        return "Mushroom Soup" + MushroomSoupQTY + " qty";
    }

    public String getLobsterSoupQTY() {
        if (setmeal == "Set Meal 3") {
            LobsterSoupQTY = LobsterSoupQTY - 1;
        }
        return "Lobster Soup" + LobsterSoupQTY + " qty";
    }

    public String getOrangeJuiceQTY() {
        if (setmeal == "Set Meal 1") {
            OrangeJuiceQTY = OrangeJuiceQTY - 1;
        }
        return "Orange Juice" + OrangeJuiceQTY + " qty";
    }

    public String getPremiumCoffeeQTY() {
        if (setmeal == "Set Meal 2" || setmeal == "Set Meal 3") {
            PremiumCoffeeQTY = PremiumCoffeeQTY - 1;
        }
        return "Premium Coffee" + PremiumCoffeeQTY + " qty";
    }

    public void StockDisplay() {
        System.out.println("Quantity of Stock Left");
        System.out.println("" + getChickenChopQTY());
        System.out.println("" + getSteakQTY());
        System.out.println("" + getLambQTY());
        System.out.println("" + getSaladQTY());
        System.out.println("" + getMushroomSoupQTY());
        System.out.println("" + getLobsterSoupQTY());
        System.out.println("" + getOrangeJuiceQTY());
        System.out.println("" + getPremiumCoffeeQTY());

    }


}
