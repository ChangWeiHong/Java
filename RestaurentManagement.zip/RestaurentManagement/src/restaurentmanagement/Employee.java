package restaurentmanagement;

public abstract class Employee{

    private double HourlyRate;
    private double WorkingHour;
    private String test;
    private String Salary;

    public Employee(int WorkingHour, double HourlyRate) {
        this.WorkingHour = WorkingHour;
        this.HourlyRate = HourlyRate;
    }
   

    public double getHourlyRate() {
        return HourlyRate;
    }

    public String getSalary() {

        return Salary;
    }

    String Job;
    String getSalary(String Job) {    
        if ("manager".equals(Job)) {
            this.Salary = "50.00";
        } else if ("chef".equals(Job)) {
            this.Salary = "40.00";
        } else if ("caiter".equals(Job)) {
            this.Salary = "30.00";
        }
        return Salary;
    }
}
