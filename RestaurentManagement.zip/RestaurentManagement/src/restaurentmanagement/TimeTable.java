package restaurentmanagement;

public class TimeTable extends Employee {

    protected String shift;
    protected String Name;
    protected String code;
    protected String Job;
    protected double WorkingHour;
    protected String Salary;
    protected int i, d;

    TimeTable(String Name, String shift, String code, String Job) {
        super(1, 1);
        this.Name = Name;
        this.shift = shift;
        this.code = code;
        this.Job = Job;
    }

    TimeTable(String Job) {
        super(1, 1);
        this.Job = Job;
    }

    TimeTable(int i, double d) {
        super(1, 1);
        this.i=i;
        this.d= (int) d;
    }

    TimeTable() {
        super(1, 1);
    }

    public String getShift() {
        return " Working Shift : " + shift;
    }

    public String getName() {
        return "" + Job + " Name : " + Name;
    }

    @Override
    public String getSalary() {
        if ("manager".equals(Job)) {
            this.Salary = "50.00";
        } else if ("chef".equals(Job)) {
            this.Salary = "40.00";
        } else if ("waiter".equals(Job)) {
            this.Salary = "30.00";
        }
        return Salary;
    }

    public String getCode() {
        return " Employee Code " + code;
    }

    public void First() {
        System.out.println("" + getName());
        System.out.println("" + getCode());
        System.out.println("" + getShift());
        //System.out.println(" Salary of for today is " + getSalary());

    }

}
