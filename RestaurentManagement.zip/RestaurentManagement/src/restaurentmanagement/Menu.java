package restaurentmanagement;

public abstract class Menu {

    String setmeal;
    private double mealprice;
    private String dishes;
    private String sidedishes;
    private String beverages;
    private float paid;
    private float change;
    private int table;
    private Bill bl;
  
    Menu(String setmeal, float paid, int table, Bill bl) {
        this.setmeal = setmeal;
        this.paid = paid;
        this.table = table;
        Bill Bill = new Bill();
        this.bl=bl;
         
    }

    public String getSetmeal() {
        return setmeal;
    }

    public String getDishes() {
        if (setmeal == "Set Meal 1") {
            dishes = "Chicken Chop";
        } else if (setmeal == "Set Meal 2") {
            dishes = "Steak";
        } else if (setmeal == "Set Meal 3") {
            dishes = "Lamb";
        }
        return " The Main Dish is " + dishes;
    }

    public String getSideDishes() {
        if (setmeal == "Set Meal 1") {
            sidedishes = "Salad";
        } else if (setmeal == "Set Meal 2") {
            sidedishes = "Mushroom Soup";
        } else if (setmeal == "Set Meal 3") {
            sidedishes = "Lobster Soup";
        }
        return " The Side Dish is " + sidedishes;
    }

    public String getBeverages() {
        if (setmeal == "Set Meal 1") {
            beverages = "Orange Juice";
        } else if (setmeal == "Set Meal 2") {
            beverages = "Premium Coffee";
        } else if (setmeal == "Set Meal 3") {
            beverages = "Premium Coffee";
        }
        return " The Beverage is " + beverages;
    }

    public String getTable() {
        return " Table number " + table;
    }

    void Second() {
        System.out.println("" + getSetmeal() + " From " + getTable()); //Print only one order from meal set 1.
        System.out.println("" + getDishes());
        System.out.println("" + getSideDishes());
        System.out.println("" + getBeverages());

    }

    void menu() {
        System.out.println("\n Welcome to ABC Restauran \n Please order your food");
        System.out.println("\n Set Meal 1:");
        System.out.println(" Chicken Chop \n Salad \n Orange Juice");
        System.out.println("\n\n Set Meal 2:");
        System.out.println(" Steak \n Mushroom Soup \n Premium Coffee");
        System.out.println("\n\n Set Meal 3");
        System.out.println(" Lamb \n Lobster Soup \n Super Premium Coffee");
    }
}
