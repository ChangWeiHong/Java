package restaurentmanagement;

public class MenuGUI extends javax.swing.JFrame {

    String itemordered;
    int[] itemqty=new int[3]; 
    boolean set1, set2, set3, dinein;
    Bill bill = new Bill(itemqty[0], itemqty[1], itemqty[2]);

    public MenuGUI() {
        initComponents();
    }

    public void getDisplayReceipt() {
        if (rbtnDineIn.isSelected()) {
            dinein = true;
        }
        if (rbtnTakeAway.isSelected()) {
            dinein = false;
        }
        if (cbxSetMeal1.isSelected()) {
            set1 = true;
        }
        if (cbxSetMeal2.isSelected()) {
            set2 = true;
        }
        if (cbxSetMeal3.isSelected()) {
            set3 = true;
        }
        
        String todinein = null;
        String tablenumber = null;
        if (dinein == true) {
            todinein = "Dine In";
            tablenumber = txtTableNumber.getText();
        } else {
            todinein = "Take Away";
            tablenumber = "No Table Number";
        }

       if (set1 == true) {
          itemqty[0]=Integer.parseInt(txtQty1.getText());
          bill.setItemqty(itemqty);
          //System.out.println(""+Integer.parseInt( txtQty1.getText()));
        }
        if (set2 == true) {
            itemqty[1]=Integer.parseInt(txtQty1.getText());
          bill.setItemqty(itemqty);
        }
        if (set3 == true) {
            itemqty[2]=Integer.parseInt(txtQty1.getText());
          bill.setItemqty(itemqty);

        }
       
        txtReceipt.append("  <<<<    Restaurant Management System    >>>>  \n"
                + "" + todinein + "\n"
                + "Table Number \t\t" + tablenumber + "\n"
                + "\n--------------------------------------------------\n"
                + "\nSet 1 Order :\t\t" +itemqty[0]+ " qty\n"
                + "\nSet 1 price :\t\tRM" +bill.getSetMeal1(itemqty)+ " \n"
                + "\nSet 2 Order :\t\t" + itemqty[1] + " qty\n"
                + "\nSet 2 price :\t\tRM" + bill.getSetMeal2(itemqty) + " \n"
                + "\nSet 3 Order :\t\t" + itemqty[2] + " qty\n"
                + "\nSet 3 price :\t\tRM" + bill.getSetMeal3(itemqty) + " \n"
                + "----------------------------------------------------"
                + "\n Total: \t RM " + (bill.getSetMeal1(itemqty) + bill.getSetMeal2(itemqty) + bill.getSetMeal3(itemqty)) + ""
                + "\n--------------------------------------------------------"
                + "\n\n---------------Thank you and come again---------------\n\n\n");

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        lblMenu = new javax.swing.JLabel();
        rbtnDineIn = new javax.swing.JRadioButton();
        rbtnTakeAway = new javax.swing.JRadioButton();
        txtTableNumber = new java.awt.TextField();
        jLabel1 = new javax.swing.JLabel();
        cbxSetMeal1 = new javax.swing.JCheckBox();
        cbxSetMeal2 = new javax.swing.JCheckBox();
        cbxSetMeal3 = new javax.swing.JCheckBox();
        jTextField1 = new javax.swing.JTextField();
        jTextField2 = new javax.swing.JTextField();
        jTextField3 = new javax.swing.JTextField();
        txtQty1 = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        txtQty2 = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        txtQty3 = new javax.swing.JTextField();
        btnOrder = new javax.swing.JButton();
        btnBack = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        btnBack1 = new javax.swing.JButton();
        txtReceipt = new java.awt.TextArea();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        lblMenu.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        lblMenu.setText("Menu");

        buttonGroup1.add(rbtnDineIn);
        rbtnDineIn.setText("Dine In");
        rbtnDineIn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbtnDineInActionPerformed(evt);
            }
        });

        buttonGroup1.add(rbtnTakeAway);
        rbtnTakeAway.setText("Take Away");
        rbtnTakeAway.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbtnTakeAwayActionPerformed(evt);
            }
        });

        txtTableNumber.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTableNumberActionPerformed(evt);
            }
        });

        jLabel1.setText("Table Number :");

        cbxSetMeal1.setText("Set Meal 1");
        cbxSetMeal1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbxSetMeal1ActionPerformed(evt);
            }
        });

        cbxSetMeal2.setText("Set Meal 2");
        cbxSetMeal2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbxSetMeal2ActionPerformed(evt);
            }
        });

        cbxSetMeal3.setText("Set Meal 3");
        cbxSetMeal3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbxSetMeal3ActionPerformed(evt);
            }
        });

        jTextField1.setText("Chicken Chop, Salad, Orange Juice");
        jTextField1.setEnabled(false);

        jTextField2.setText("Grill Steak, Mushroom Soup, Premium Coffee");
        jTextField2.setEnabled(false);

        jTextField3.setText("Grill Lamb, Lobster Soup, Super Premium Coffee");
        jTextField3.setEnabled(false);

        txtQty1.setEnabled(false);

        jLabel2.setText("Qty :");

        jLabel3.setText("Qty :");

        txtQty2.setEnabled(false);

        jLabel4.setText("Qty :");

        txtQty3.setEnabled(false);

        btnOrder.setText("Order");
        btnOrder.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnOrderActionPerformed(evt);
            }
        });

        btnBack.setText("Back");
        btnBack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBackActionPerformed(evt);
            }
        });

        jLabel5.setText("Receipt");

        btnBack1.setText("Clear");
        btnBack1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBack1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(46, 46, 46)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(lblMenu)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(cbxSetMeal2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txtQty2, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(cbxSetMeal3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txtQty3, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jTextField1)
                    .addComponent(jTextField2)
                    .addComponent(jTextField3)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(rbtnDineIn)
                                    .addComponent(jLabel1))
                                .addGap(28, 28, 28)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(rbtnTakeAway)
                                    .addComponent(txtTableNumber, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(cbxSetMeal1))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 15, Short.MAX_VALUE)
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txtQty1, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(btnOrder, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(34, 34, 34)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(btnBack1)
                                .addGap(34, 34, 34)
                                .addComponent(btnBack))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel5)
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addGap(38, 38, 38))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(txtReceipt, javax.swing.GroupLayout.PREFERRED_SIZE, 412, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblMenu)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(rbtnDineIn)
                    .addComponent(rbtnTakeAway)
                    .addComponent(jLabel5))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1)
                            .addComponent(txtTableNumber, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(cbxSetMeal1)
                            .addComponent(txtQty1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel2))
                        .addGap(6, 6, 6)
                        .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(cbxSetMeal2)
                            .addComponent(txtQty2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3))
                        .addGap(18, 18, 18)
                        .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(cbxSetMeal3)
                            .addComponent(txtQty3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel4))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(53, 53, 53)
                        .addComponent(btnOrder, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(txtReceipt, javax.swing.GroupLayout.PREFERRED_SIZE, 483, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 62, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnBack)
                    .addComponent(btnBack1))
                .addGap(20, 20, 20))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void rbtnDineInActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbtnDineInActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rbtnDineInActionPerformed

    private void rbtnTakeAwayActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbtnTakeAwayActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rbtnTakeAwayActionPerformed

    private void txtTableNumberActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTableNumberActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtTableNumberActionPerformed

    private void btnBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackActionPerformed
        new MainGUI().setVisible(true);
        dispose();
    }//GEN-LAST:event_btnBackActionPerformed

    private void btnBack1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBack1ActionPerformed
        txtReceipt.setText(" ");
    }//GEN-LAST:event_btnBack1ActionPerformed

    private void btnOrderActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnOrderActionPerformed
        getDisplayReceipt();

    }//GEN-LAST:event_btnOrderActionPerformed

    private void cbxSetMeal1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbxSetMeal1ActionPerformed
        if (cbxSetMeal1.isSelected()) {
            txtQty1.setEnabled(true);
        } else {
            txtQty1.setEnabled(false);
        }
    }//GEN-LAST:event_cbxSetMeal1ActionPerformed

    private void cbxSetMeal2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbxSetMeal2ActionPerformed
        if (cbxSetMeal2.isSelected()) {
            txtQty2.setEnabled(true);
        } else {
            txtQty2.setEnabled(false);
        }
    }//GEN-LAST:event_cbxSetMeal2ActionPerformed

    private void cbxSetMeal3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbxSetMeal3ActionPerformed
        if (cbxSetMeal3.isSelected()) {
            txtQty3.setEnabled(true);
        } else {
            txtQty3.setEnabled(false);
        }
    }//GEN-LAST:event_cbxSetMeal3ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MenuGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MenuGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MenuGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MenuGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MenuGUI().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBack;
    private javax.swing.JButton btnBack1;
    private javax.swing.JButton btnOrder;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JCheckBox cbxSetMeal1;
    private javax.swing.JCheckBox cbxSetMeal2;
    private javax.swing.JCheckBox cbxSetMeal3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JLabel lblMenu;
    private javax.swing.JRadioButton rbtnDineIn;
    private javax.swing.JRadioButton rbtnTakeAway;
    private javax.swing.JTextField txtQty1;
    private javax.swing.JTextField txtQty2;
    private javax.swing.JTextField txtQty3;
    private java.awt.TextArea txtReceipt;
    private java.awt.TextField txtTableNumber;
    // End of variables declaration//GEN-END:variables
}
