package restaurentmanagement;
public class Bill {

    private int setmeal;
    private double paid;
    private double mealprice;

    private int[] itemqty=new int[3];
  
    
    public Bill(int itemqty1, int itemqty2, int itemqty3) {
        this.itemqty[0] = itemqty1;
        this.itemqty[1] = itemqty2;
        this.itemqty[2] = itemqty3;
    }

   public Bill() {
        
    }

    public void setSetmeal(int setmeal) {
        this.setmeal = setmeal;
    }

    public void setSetmeal1(int setmeal) {
        this.setmeal = setmeal;
    }
    public double getMealprice() {

        if (setmeal == 1) {
            mealprice = 30.0;
        } if (setmeal == 2) {
            mealprice = 35.00;
        } if (setmeal == 3) {
            mealprice = 40.00;
        } 
        
        return mealprice;
    }

    public void setItemqty(int[] itemqty) {
        this.itemqty = itemqty;
    }

  
    public int getSetMeal1(int[] itemqty){
        return itemqty[0]*20;
    }

    public int getSetMeal2(int[] itemqty){
        return itemqty[1]*30;    
    }
    public int getSetMeal3(int[] itemqty){
        return itemqty[2]*40;
    }

    public int getTemp() {
        return setmeal;
    }

    public void setPaid(double paid) {
        this.paid = paid;
    }

    public String getPaid() {
        return " Customer Paid RM" + paid;
    }

    public String getChange() {
        double change;
        change = (paid - mealprice);
        return " The Change is RM" + change;
    }

    void ForBill() {
        System.out.println("" + getMealprice());
        System.out.println("" + getPaid());
        System.out.println("" + getChange());
    }




}
